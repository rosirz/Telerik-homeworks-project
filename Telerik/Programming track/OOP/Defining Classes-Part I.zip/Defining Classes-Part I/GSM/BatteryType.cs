﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Problem 3. Enumeration

//Add an enumeration BatteryType(Li-Ion, NiMH, NiCd, …) and use it as a new field for the batteries
namespace GSM
{
    enum BatteryType
    {
        //(Li-Ion, NiMH, NiCd
        LiIon,
        NiNH,
        NiCd
    }
}
