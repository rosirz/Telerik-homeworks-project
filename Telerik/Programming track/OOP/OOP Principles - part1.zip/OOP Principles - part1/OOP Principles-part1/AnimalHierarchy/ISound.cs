﻿namespace AnimalHierarchy
{
    internal interface ISound
    {
        void MakeSound();
    }
}